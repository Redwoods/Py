# wk02_02_string.py
#
print("숫자형: 정수")
a = 123
a = -178
a = 0
print("숫자형: 실수")
a = 1.2
a = -3.48
a = 4.24E10
a = 4.24e-10
print("숫자형: 8진수와 16진수")
a = 0o177
a
a = 0x8ff
a
a = 0xABC
a
print("숫자형: 연산자와 연산")
a = 3
b = 4
a+b
a*b
a/b
a**b
a % b
a//b

14//3
14 % 3

"""
Author: redwoods
파이썬 코드: wk02_01_numeric.py
"""
