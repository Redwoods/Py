# mod1.py
def add(a, b):
    return a + b

def sub(a, b): 
    return a-b

print(add(1, 4))
print(sub(4, 2))
