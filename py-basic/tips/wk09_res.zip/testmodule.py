#!/usr/bin/env python

import sys                # 표준 라이브러리를 임포트

a = 1                     # 변수를 정의함
b = "some string"

def foo():                # 함수를 정의함
    print("This is the function 'foo'")

print("this is the top level") # 문자열을 표시함

if __name__ == '__main__':
    print("this is the code block")
