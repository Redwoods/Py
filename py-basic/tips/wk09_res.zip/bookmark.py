#!/usr/bin/env python

class Bookmark:
    """
    북마크 모듈
    """

    def __init__(self, title, url):
        self.title = title
        self.url = url

